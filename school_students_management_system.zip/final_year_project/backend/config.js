module.exports = {
  db: {
    host: 'localhost',
    user: 'root',
    password: 'root',
    database: 'school'
  }
};
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/NavBar';
import Slider from './components/Slider';
import AboutSchool from './components/AboutSchool';
import Footer from './components/Footer';
import Login from './components/Login';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={
          <>
            <Navbar />
            <Slider />
            <AboutSchool />
            <Footer />
          </>
        } />
        <Route path="/login/*" element={<Login />} />
      </Routes>
    </Router>
  );
}

export default App;
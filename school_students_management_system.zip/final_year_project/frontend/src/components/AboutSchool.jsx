function AboutSchool() {
  return (
    <div className="bg-gray-100 h-screen p-4 flex justify-center items-center">
      <div className="w-4/5 h-4/5 overflow-y-auto p-4 bg-white rounded-lg shadow-md">
        <h2 className="text-2xl font-bold mb-4">About Our School</h2>
        
        <p className="text-gray-600 mb-4 leading-relaxed">
          Bannari Amman Institute of Technology is an Autonomous, Self-financing Engineering College, Approved by AICTE, New Delhi and Affiliated to Anna University, Chennai. Nestled on the banks of The River Bhavani, BIT campus provides environment for learning in harmony with nature, away from the odds of the city life.
        </p>
        
        <p className="text-gray-600 mb-4 leading-relaxed">
          The spacious and the earth hugging buildings punctuated with landscaped courtyards and pathways are designed to emphasise the business ethics and or characteristics of an excellent centre for learning. The Campus hosts well planned academic blocks, computer centres, lecture halls, libraries, laboratories, conference halls, staff quarters, hostels and students' centres.
        </p>
        
        <p className="text-gray-600 mb-4 leading-relaxed">
          The Campus also houses a co-operative store, ATM (Axis, SBI and KVB) and a clinic to attend to the general health of the students and staff.
        </p>

        <p className="text-gray-600 mb-4 leading-relaxed">
          The spacious and the earth hugging buildings punctuated with landscaped courtyards and pathways are designed to emphasise the business ethics and or characteristics of an excellent centre for learning. The Campus hosts well planned academic blocks, computer centres, lecture halls, libraries, laboratories, conference halls, staff quarters, hostels and students' centres.
        </p>

        <p className="text-gray-600 mb-4 leading-relaxed">
          The Campus also houses a co-operative store, ATM (Axis, SBI and KVB) and a clinic to attend to the general health of the students and staff.
        </p>
        
      </div>
    </div>
  );
}

export default AboutSchool;
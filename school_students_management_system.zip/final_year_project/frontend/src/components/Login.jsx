import React from 'react';
import { Link, Routes, Route } from 'react-router-dom';
import StudentLogin from './logins/StudentLogin';
import AdminLogin from './logins/AdminLogin';
import TeacherLogin from './logins/TeacherLogin';
import ParentLogin from './logins/ParentLogin';

function Login() {
  return (
    <div className="flex justify-center items-center h-screen bg-gray-100">
      <div className="bg-white p-10 rounded-lg shadow-lg w-1/2 md:w-1/3 xl:w-1/4">
        <h2 className="text-lg font-bold mb-4 text-center">Select Login Type</h2>
        <div className="flex flex-col items-center">
          <Link to="/login/student-login">
            <button className="text-gray-600 py-2 px-4 rounded mb-4 hover:bg-blue-500 hover:text-white transition duration-200">
              Student Login
            </button>
          </Link>
          <Link to="/login/admin-login">
            <button className="text-gray-600 py-2 px-4 rounded mb-4 hover:bg-blue-500 hover:text-white transition duration-200">
              Admin Login
            </button>
          </Link>
          <Link to="/login/teacher-login">
            <button className="text-gray-600 py-2 px-4 rounded mb-4 hover:bg-blue-500 hover:text-white transition duration-200">
              Teacher Login
            </button>
          </Link>
          <Link to="/login/parent-login">
            <button className="text-gray-600 py-2 px-4 rounded mb-4 hover:bg-blue-500 hover:text-white transition duration-200">
              Parent Login
            </button>
          </Link>
        </div>
      </div>
      <Routes>
        <Route path="student-login" element={<StudentLogin />} />
        <Route path="admin-login" element={<AdminLogin />} />
        <Route path="teacher-login" element={<TeacherLogin />} />
        <Route path="parent-login" element={<ParentLogin />} />
      </Routes>
    </div>
  );
}

export default Login;
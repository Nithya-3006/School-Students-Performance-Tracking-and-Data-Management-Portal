import React, { useState, useEffect } from "react";
import axios from "axios";

const TeacherDashboard = () => {
  const [students, setStudents] = useState([]);
  const [page, setPage] = useState(0);
  const studentsPerPage = 10;

  useEffect(() => {
    const fetchStudents = async () => {
      try {
        const response = await axios.get('http://localhost:3000/students');
        setStudents(response.data);
      } catch (error) {
        console.error('Error fetching students:', error);
      }
    };

    fetchStudents();
  }, []);

  const startIndex = page * studentsPerPage;
  const paginatedStudents = students.slice(startIndex, startIndex + studentsPerPage);

  return (
    <div className="bg-gray-100 min-h-screen p-4 flex justify-center">
      <div className="max-w-5xl w-full bg-white shadow-lg rounded-lg p-6 overflow-auto">
        <h2 className="text-2xl font-bold mb-4 text-gray-800">Teacher Dashboard</h2>
        <hr className="mb-4 border-gray-300" />

        {/* Teacher Details */}
        <h3 className="text-xl font-semibold mb-3 text-gray-700">Teacher Details</h3>
        <div className="mb-6 p-4 border rounded-lg bg-gray-50">
          <p className="text-lg">Name: John Doe</p>
          <p className="text-lg">Email: johndoe@example.com</p>
          <p className="text-lg">Phone: 123-456-7890</p>
        </div>

        {/* Students Table */}
        <h3 className="text-xl font-semibold mt-6 mb-3 text-gray-700">Students Details</h3>
        <div className="max-h-64 overflow-auto">
          <table className="w-full border border-gray-300 rounded-lg overflow-hidden shadow-sm">
            <thead>
              <tr className="bg-gray-200 text-gray-700 text-left">
                <th className="px-4 py-2">Student Name</th>
                <th className="px-4 py-2">Standard</th>
                <th className="px-4 py-2">Attendance %</th>
                <th className="px-4 py-2">Cumulative Average</th>
                <th className="px-4 py-2">Weekly Tests</th>
                <th className="px-4 py-2">Academic %</th>
                <th className="px-4 py-2">Parent Name</th>
                <th className="px-4 py-2">Parent Email</th>
                <th className="px-4 py-2">Parent Phone</th>
              </tr>
            </thead>
            <tbody>
              {paginatedStudents.map((student) => (
                <tr key={student.id} className="border-b hover:bg-gray-100 text-gray-800">
                  <td className="px-4 py-2">{student.name}</td>
                  <td className="px-4 py-2">{student.rollNo}</td>
                  <td className="px-4 py-2">{student.attendance || 'N/A'}</td>
                  <td className="px-4 py-2">{student.average || 'N/A'}</td>
                  <td className="px-4 py-2">{student.weeklyTests || 'N/A'}</td>
                  <td className="px-4 py-2">{student.academicPercentage || 'N/A'}</td>
                  <td className="px-4 py-2">{student.parentName || 'N/A'}</td>
                  <td className="px-4 py-2">{student.parentEmail || 'N/A'}</td>
                  <td className="px-4 py-2">{student.parentPhone || 'N/A'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="flex justify-between mt-4">
          <button
            className="bg-blue-600 text-white px-3 py-1 rounded-lg hover:bg-blue-700 disabled:opacity-50"
            onClick={() => setPage(page - 1)}
            disabled={page === 0}
          >
            Previous
          </button>
          <button
            className="bg-green-600 text-white px-3 py-1 rounded-lg hover:bg-green-700 disabled:opacity-50"
            onClick={() => setPage(page + 1)}
            disabled={startIndex + studentsPerPage >= students.length}
          >
            Next
          </button>
        </div>
      </div>
    </div>
  );
};

export default TeacherDashboard;
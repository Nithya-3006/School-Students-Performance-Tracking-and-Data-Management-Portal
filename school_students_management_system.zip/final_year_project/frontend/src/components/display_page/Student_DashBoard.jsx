import React from "react";

const Student_Dashboard = () => {
  return (
    <div className="bg-gray-50 min-h-screen p-8">
      <div className="max-w-6xl mx-auto bg-white shadow-lg rounded-lg p-6">
        <div className="flex items-center justify-between mb-2">
          {/* Profile Section */}
          <div className="flex items-start gap-6">
            
            <div>
              <h1 className="text-xl font-bold">NITHYASRI V</h1>
              <p className="text-sm text-gray-600">7376211CS234</p>
              <p className="text-sm text-purple-700 font-semibold">VIII - Standard (CONTINUING)</p>
              <p className="text-sm">Mentor: <span className="text-blue-500">CHITRADEVI T N</span></p>
              <p className="text-sm">Extracurricular Activities: <span className="text-red-500">Inactive</span></p>
              <p className="text-sm">Location: Anthiyur</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Attendance Overview */}
          <div className="bg-gray-100 p-4 rounded-lg">
            <h2 className="text-lg font-bold mb-4">Attendance Overview</h2>
            <div className="grid grid-cols-2 gap-4">
              <div className="flex items-center gap-2">
                <div className="text-green-600 font-bold text-xl">21</div>
                <div className="text-sm">Total Days</div>
              </div>
              <div className="flex items-center gap-2">
                <div className="text-orange-600 font-bold text-xl">12</div>
                <div className="text-sm">Present Days</div>
              </div>
              <div className="flex items-center gap-2">
                <div className="text-blue-600 font-bold text-xl">8</div>
                <div className="text-sm">On Duty</div>
              </div>
              <div className="flex items-center gap-2">
                <div className="text-red-600 font-bold text-xl">1</div>
                <div className="text-sm">Leave</div>
              </div>
            </div>
            
            <p className="mt-1 text-xs text-red-500">
              Note: 80% Attendance is mandatory to appear for Public Examination
            </p>
          </div>

          {/* SGPA */}
          <div className="bg-gray-100 p-4 rounded-lg">
            <h2 className="text-lg font-bold mb-4">Percentage of academic scoring</h2>
            <div className="grid grid-cols-6 gap-2 text-center">
              {[90, 98, 85, 78, 89, 95].map((sgpa, index) => (
                <div key={index}>
                  <div className="text-sm text-gray-600">{index + 1}</div>
                  <div className="text-blue-600 font-bold">{sgpa}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-6">
          {/* CGPA */}
          <div className="bg-gray-100 p-4 rounded-lg text-center">
            <h2 className="text-lg font-bold">Cumulative Average</h2>
            <div className="text-blue-600 font-bold text-2xl">84</div>
          </div>

          {/* Placement Percentage */}
          <div className="bg-gray-100 p-4 rounded-lg text-center">
            <h2 className="text-lg font-bold">Weekly Tests</h2>
            <div className="text-blue-600 font-bold text-2xl">70.3</div>
          </div>

          {/* Formative Assessment */}
          <div className="bg-gray-100 p-4 rounded-lg text-center">
            <h2 className="text-lg font-bold">Formative Assessment (Academic %)</h2>
            <div className="text-blue-600 font-bold text-2xl">89</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Student_Dashboard;

import React from "react";
import StudentDashboard from "./Student_DashBoard";

const ParentDashboard = () => {
  return (
    <div className="bg-gray-50 min-h-screen p-8 mt-40">
      <div className="max-w-5xl mx-auto bg-white shadow-lg rounded-lg p-2">
        <div className="mb-20"></div>
        <h2 className="text-2xl font-bold mb-2">Parent Dashboard</h2>
        <div className="p-2 mb-2">
          <h2 className="text-xl font-bold mb-2">Parent Details</h2>
          <div className="flex flex-col">
            <p className="text-lg">Name: John Doe</p>
            <p className="text-lg">Email: johndoe@example.com</p>
            <p className="text-lg">Phone: 123-456-7890</p>
          </div>
        </div>
        <div className="p-2">
          <StudentDashboard />
        </div>
      </div>
    </div>
  );
};

export default ParentDashboard;
import React, { useState, useEffect } from "react";
import axios from "axios";

const AdminDashboard = ({ setIsLoggedIn }) => {
  const [teachers, setTeachers] = useState([]);
  const [students, setStudents] = useState([]);
  const [page, setPage] = useState(0);
  const studentsPerPage = 10;

  const handleLogout = () => {
    localStorage.removeItem('token');
    setIsLoggedIn(false);
  };

  useEffect(() => {
    const fetchTeachers = async () => {
      try {
        const response = await axios.get('http://localhost:3000/teachers');
        
        setTeachers(response.data);
      } catch (error) {
        console.error(error);
      }
    };

    const fetchStudents = async () => {
      try {
        const response = await axios.get('http://localhost:3000/students');
        console.log(response.data);
        setStudents(response.data);
      } catch (error) {
        console.error('Error fetching students:', error);
        if (error.response) {
          console.error('Response data:', error.response.data);
          console.error('Response status:', error.response.status);
        } else {
          console.error('Error message:', error.message);
        }
      }
    };

    fetchTeachers();
    fetchStudents();
  }, []);

  const startIndex = page * studentsPerPage;
  const paginatedStudents = students.slice(startIndex, startIndex + studentsPerPage);

  return (
    <div className="bg-gray-100 min-h-screen p-4 flex justify-center">
      <div className="max-w-5xl w-full bg-white shadow-lg rounded-lg p-6">
        <div className="flex justify-between items-center">
          <br /><br />
          <h2 className="text-2xl font-bold mb-4 text-gray-800">Admin Dashboard</h2>
          <button
            className=" text-white px-3 py-1 rounded-lg hover:bg-red-700"
            onClick={handleLogout}
          >
            Logout
          </button>
        </div>
        <hr className="mb-4 border-gray-300" />

        {/* Teachers Table */}
        <h3 className="text-xl font-semibold mb-3 text-gray-700">Teachers Details</h3>
        <div className="max-h-48 overflow-auto">
          <table className="w-full border border-gray-300 rounded-lg overflow-hidden shadow-sm">
            <thead>
              <tr className="bg-gray-200 text-gray-700 text-left">
                <th className="px-4 py-2">Teacher Name</th>
                <th className="px-4 py-2">Teacher Email</th>
                <th className="px-4 py-2">Teacher Subject</th>
              </tr>
            </thead>
            <tbody>
              {teachers.map((teacher) => (
                <tr key={teacher.id} className="border-b hover:bg-gray-100">
                  <td className="px-4 py-2">{teacher.name}</td>
                  <td className="px-4 py-2">{teacher.email}</td>
                  <td className="px-4 py-2">{teacher.subject || 'N/A'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Students Table */}
        <h3 className="text-xl font-semibold mt-6 mb-3 text-gray-700">Students Details</h3>
        <div className="max-h-64 overflow-auto">
          <table className="w-full border border-gray-300 rounded-lg overflow-hidden shadow-sm">
            <thead>
              <tr className="bg-gray-200 text-gray-700 text-left">
                <th className="px-4 py-2">Student Name</th>
                <th className="px-4 py-2">Standard</th>
                <th className="px-4 py-2">Attendance %</th>
                <th className="px-4 py-2">Cumulative Average</th>
                <th className="px-4 py-2">Weekly Tests</th>
                <th className="px-4 py-2">Academic %</th>
                <th className="px-4 py-2">Teacher Name</th>
                <th className="px-4 py-2">Parent Name</th>
                <th className="px-4 py-2">Parent Email</th>
                <th className="px-4 py-2">Parent Phone</th>
              </tr>
            </thead>
            <tbody>
            {paginatedStudents.map((student) => (
  <tr key={student.id} className="border-b hover:bg-gray-100 text-gray-800">
    <td className="px-4 py-2">{student.name}</td>
    <td className="px-4 py-2">{student.rollNo || 'N/A'}</td>
    <td className="px-4 py-2">{student.attendance || 'N/A'}</td>
    <td className="px-4 py-2">{student.average || 'N/A'}</td>
    <td className="px-4 py-2">{student.weeklyTests || 'N/A'}</td>
    <td className="px-4 py-2">{student.academicPercentage || 'N/A'}</td>
    <td className="px-4 py-2">{student.teacherName || 'N/A'}</td>
    <td className="px-4 py-2">{student.parentName || 'N/A'}</td>
    <td className="px-4 py-2">{student.parentEmail || 'N/A'}</td>
    <td className="px-4 py-2">{student.parentPhone || 'N/A'}</td>
  </tr>
))}
            </tbody>
          </table>
        </div>

        <div className="flex justify-between mt-4">
          <button
            className="bg-blue-600 text-white px-3 py-1 rounded-lg hover:bg-blue-700 disabled:opacity-50"
            onClick={() => setPage(page - 1)}
            disabled={page === 0}
          >
            Previous
          </button>
          <button
            className="bg-green-600 text-white px-3 py-1 rounded-lg hover:bg-green-700 disabled:opacity-50"
            onClick={() => setPage(page + 1)}
            disabled={startIndex + studentsPerPage >= students.length}
          >
            Next
          </button>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
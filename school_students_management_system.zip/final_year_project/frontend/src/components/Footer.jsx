import React from 'react';

function Footer() {
  return (
    <footer className="bg-gray-200 text-gray-600 body-font">
      <div className="container mx-auto py-4 px-5 flex flex-wrap flex-col sm:flex-row justify-center items-center">
        <div className="w-full sm:w-1/3 xl:w-1/3 p-4">
          <h2 className="text-lg font-bold mb-4">Contact Us</h2>
          <ul>
            <li className="mb-2">Phone: +91 98765 43210</li>
            <li className="mb-2">Email: <a href="mailto:info@example.com" className="text-blue-600 hover:text-blue-800">info@example.com</a></li>
            <li className="mb-2">Address: 123, Main Street, Anytown, USA</li>
          </ul>
        </div>
        <div className="w-full sm:w-1/3 xl:w-1/3 p-4">
          <h2 className="text-lg font-bold mb-4">Social Media</h2>
          <ul>
            <li className="mb-2">
              <a href="https://www.facebook.com/" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:text-blue-800">Facebook</a>
            </li>
            <li className="mb-2">
              <a href="https://www.twitter.com/" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:text-blue-800">Twitter</a>
            </li>
            <li className="mb-2">
              <a href="https://www.instagram.com/" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:text-blue-800">Instagram</a>
            </li>
          </ul>
        </div>
        <div className="w-full sm:w-1/3 xl:w-1/3 p-4">
          <h2 className="text-lg font-bold mb-4">Copyright</h2>
          <p className="text-gray-600 text-sm">&copy; 2023 All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}

export default Footer;
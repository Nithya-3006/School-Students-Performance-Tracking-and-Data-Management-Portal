function MainPage() {
    return (
      <div className="flex flex-col h-screen">
        <Slider />
        <AboutSchool />
        <ContactDetails />
      </div>
    );
  }
  export default MainPage;
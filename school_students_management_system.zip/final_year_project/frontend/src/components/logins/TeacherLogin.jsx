import React, { useState } from 'react';
import axios from 'axios';
import TeacherDashboard from '../display_page/TeacherDashboard';
import LoginLayout from './LoginLayout';

function TeacherLogin() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [error, setError] = useState('');

  const handleLogin = async (e) => {
    e.preventDefault();
    setError('');
    try {
      const response = await axios.post('http://localhost:3000/login/teacher', { username, password });
      if (response.status === 200) {
        setIsLoggedIn(true);
      } else {
        setError('Invalid credentials');
      }
    } catch (error) {
      setError('An error occurred. Please try again.');
    }
  };

  if (isLoggedIn) return <TeacherDashboard />;

  return (
    <LoginLayout
      title="Teacher Login"
      accentColor="green"
      handleLogin={handleLogin}
      username={username}
      password={password}
      setUsername={setUsername}
      setPassword={setPassword}
      error={error}
    />
  );
}

export default TeacherLogin;
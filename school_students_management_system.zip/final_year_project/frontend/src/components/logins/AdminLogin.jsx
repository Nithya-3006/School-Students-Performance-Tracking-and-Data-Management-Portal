import React, { useState } from 'react';
import axios from 'axios';
import AdminDashboard from '../display_page/AdminDashboard';
import LoginLayout from "./LoginLayout";

function AdminLogin() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [error, setError] = useState('');

  const handleLogin = async (e) => {
    e.preventDefault();
    setError('');
    try {
      const response = await axios.post('http://localhost:3000/login/admin', { username, password });      if (response.status === 200) {
        setIsLoggedIn(true);
      } else {
        setError('Invalid credentials');
      }
    } catch (error) {
      if (error.response) {
        setError(error.response.data.message);
      } else {
        setError('An error occurred. Please try again.');
      }
    }
  };

  if (isLoggedIn) return <AdminDashboard />;

  return (
    <LoginLayout
      title="Admin Login"
      accentColor="green"
      handleLogin={handleLogin}
      username={username}
      password={password}
      setUsername={setUsername}
      setPassword={setPassword}
      error={error}
    />
  );
}

export default AdminLogin;
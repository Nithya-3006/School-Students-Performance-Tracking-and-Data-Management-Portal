import React from 'react';

function LoginLayout({
  title,
  accentColor,
  handleLogin,
  username,
  password,
  setUsername,
  setPassword,
  error
}) {
  return (
    <div className="flex justify-center items-center h-screen bg-gray-100">
      <div className="flex flex-col lg:flex-row shadow-lg rounded-lg overflow-hidden max-w-4xl w-full">
        {/* Left Panel */}
        <div className={`hidden lg:flex lg:w-1/3 bg-${accentColor}-600 p-6 items-center justify-center`}>
          <h1 className="text-3xl font-bold text-white">{title}</h1>
        </div>

        {/* Right Panel */}
        <div className="w-full lg:w-2/3 bg-white p-6 flex flex-col justify-between">
          <div className="text-right text-sm text-gray-600">
            <a href="#" className={`text-${accentColor}-600 hover:underline`}>Need help?</a>
          </div>
          <div className="flex flex-col justify-center flex-grow">
            <h2 className="text-3xl font-bold text-gray-800 mb-4">Log in</h2>

            {error && (
              <div className="mb-4 text-red-500 text-center bg-red-100 border border-red-400 rounded-lg p-2">
                {error}
              </div>
            )}

            <form onSubmit={handleLogin}>
              <div className="mb-5">
                <label className="block text-gray-700 text-sm font-medium mb-2">Username:</label>
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="shadow-sm border border-gray-300 rounded-lg w-full py-2.5 px-4 focus:outline-none focus:ring-2 focus:ring-${accentColor}-500"
                  placeholder="username"
                  required
                />
              </div>

              <div className="mb-5">
                <label className="block text-gray-700 text-sm font-medium mb-2">Password:</label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="shadow-sm border border-gray-300 rounded-lg w-full py-2.5 px-4 focus:outline-none focus:ring-2 focus:ring-${accentColor}-500"
                  placeholder="password"
                  required
                />
              </div>

              <button
                type="submit"
                className={`w-full bg-${accentColor}-600 hover:bg-${accentColor}-700 text-white font-bold py-2.5 rounded-lg`}
              >
                Login
              </button>
              <p className="mt-5 text-sm text-gray-600 text-center">
                Need help? <a href="#" className={`text-${accentColor}-600 hover:underline`}>Contact Management</a>
              </p>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}

export default LoginLayout;
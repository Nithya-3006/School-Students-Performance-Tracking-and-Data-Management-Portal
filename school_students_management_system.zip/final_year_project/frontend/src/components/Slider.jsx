import React from 'react';
import image from '../assets/slider1.png';
import images from '../assets/slider2.png';
import imagess from '../assets/silder3.png';

function Slider() {
  const [activeIndex, setActiveIndex] = React.useState(0);

  const handleNext = () => {
    setActiveIndex((prevIndex) => (prevIndex + 1) % 3);
  };

  const handlePrev = () => {
    setActiveIndex((prevIndex) => (prevIndex - 1 + 3) % 3);
  };

  return (
    <div className="bg-gray-300 h-screen flex justify-center items-center relative">
      <div className="w-4/5 h-4/5">
        <div className="relative w-full h-full overflow-hidden rounded-lg shadow-lg">
          {[
            { image: image, alt: 'Slide 1' },
            { image: images, alt: 'Slide 2' },
            { image: imagess, alt: 'Slide 3' },
          ].map((slide, index) => (
            <div
              key={index}
              className={`absolute top-0 left-0 w-full h-full ${
                activeIndex === index ? 'block' : 'hidden'
              }`}
            >
              <img src={slide.image} alt={slide.alt} className="object-cover w-full h-full" />
            </div>
          ))}
        </div>
      </div>
      <button
        className="absolute top-1/2 left-0 transform -translate-y-1/2 px-4 py-2 ml-4 bg-gray-200 hover:bg-gray-300 rounded-lg shadow-md"
        onClick={handlePrev}
      >
        Prev
      </button>
      <button
        className="absolute top-1/2 right-0 transform -translate-y-1/2 px-4 py-2 mr-4 bg-gray-200 hover:bg-gray-300 rounded-lg shadow-md"
        onClick={handleNext}
      >
        Next
      </button>
    </div>
  );
}

export default Slider;
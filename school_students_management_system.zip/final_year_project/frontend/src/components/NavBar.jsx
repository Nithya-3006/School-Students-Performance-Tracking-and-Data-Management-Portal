import { Link, useLocation } from 'react-router-dom';

function Navbar() {
  const location = useLocation();

  return (
    <div>
      {location.pathname !== '/login' && (
        <nav className="bg-gray-900 text-white p-4 flex justify-between items-center shadow-md">
          <Link to="/" className="text-2xl font-bold hover:text-gray-400 transition duration-200">
            Bannari Amman Public School
          </Link>
          <ul className="flex space-x-4">
            <li>
              <Link to="/login" className="text-lg hover:text-gray-400 transition duration-200">
                Login
              </Link>
            </li>
            
          </ul>
        </nav>
      )}
    </div>
  );
}

export default Navbar;